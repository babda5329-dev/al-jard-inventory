package com.example.data.model

data class InventorySessionSummary(
    val id: String,
    val name: String,
    val createdAt: Long,
    val itemCount: Int,
    val grandTotal: Double
)
