package com.example.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "inventory_items",
    indices = [Index(value = ["sessionId"])]
)
data class InventoryItem(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    @ColumnInfo(name = "sessionId", defaultValue = "legacy_inventory")
    val sessionId: String = "legacy_inventory",
    val name: String,
    val quantity: Double,
    val price: Double,
    val total: Double,
    val details: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
