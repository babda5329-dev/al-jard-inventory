package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class InventoryBackupData(
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val appName: String = "الجرد المخزني",
    val sessions: List<BackupSession> = emptyList(),
    val items: List<BackupItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class BackupSession(
    val id: String,
    val name: String,
    val createdAt: Long
)

@JsonClass(generateAdapter = true)
data class BackupItem(
    val id: String,
    val sessionId: String,
    val name: String,
    val quantity: Double,
    val price: Double,
    val total: Double,
    val details: String? = null,
    val timestamp: Long
)
