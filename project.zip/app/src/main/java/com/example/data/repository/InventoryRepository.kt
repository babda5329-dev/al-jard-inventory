package com.example.data.repository

import com.example.data.local.InventoryDao
import com.example.data.model.InventoryItem
import com.example.data.model.InventorySession
import com.example.data.model.InventorySessionSummary
import kotlinx.coroutines.flow.Flow

class InventoryRepository(private val dao: InventoryDao) {

    val allSessions: Flow<List<InventorySession>> = dao.getAllSessions()
    val allSessionSummaries: Flow<List<InventorySessionSummary>> = dao.getAllSessionSummaries()

    fun getItemsForSession(sessionId: String): Flow<List<InventoryItem>> =
        dao.getItemsForSession(sessionId)

    val allItems: Flow<List<InventoryItem>> = dao.getAllItems()

    suspend fun getAllSessionsList(): List<InventorySession> = dao.getAllSessionsList()

    suspend fun getAllItemsList(): List<InventoryItem> = dao.getAllItemsList()

    suspend fun getSessionById(sessionId: String): InventorySession? =
        dao.getSessionById(sessionId)

    suspend fun addSession(session: InventorySession) =
        dao.insertSession(session)

    suspend fun deleteSession(sessionId: String) {
        dao.deleteItemsForSession(sessionId)
        dao.deleteSessionById(sessionId)
    }

    suspend fun checkAndMigrateLegacyItems() {
        val legacyCount = dao.getLegacyItemsCount()
        if (legacyCount > 0) {
            val existingLegacy = dao.getSessionById("legacy_inventory")
            if (existingLegacy == null) {
                dao.insertSession(
                    InventorySession(
                        id = "legacy_inventory",
                        name = "الجرد السابق",
                        createdAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    suspend fun addItem(item: InventoryItem) = dao.insertItem(item)

    suspend fun updateItem(item: InventoryItem) = dao.updateItem(item)

    suspend fun deleteItem(item: InventoryItem) = dao.deleteItem(item)

    suspend fun deleteItemById(id: String) = dao.deleteItemById(id)

    suspend fun restoreDatabase(
        sessions: List<InventorySession>,
        items: List<InventoryItem>,
        clearExisting: Boolean
    ) {
        dao.restoreDatabase(sessions, items, clearExisting)
    }
}
