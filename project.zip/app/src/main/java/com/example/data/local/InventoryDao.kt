package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.InventoryItem
import com.example.data.model.InventorySession
import com.example.data.model.InventorySessionSummary
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {

    // === SESSIONS ===
    @Query("SELECT * FROM inventory_sessions ORDER BY createdAt DESC")
    fun getAllSessions(): Flow<List<InventorySession>>

    @Query("SELECT * FROM inventory_sessions ORDER BY createdAt DESC")
    suspend fun getAllSessionsList(): List<InventorySession>

    @Query("""
        SELECT s.id, s.name, s.createdAt, 
               COUNT(i.id) AS itemCount, 
               COALESCE(SUM(i.total), 0.0) AS grandTotal 
        FROM inventory_sessions s 
        LEFT JOIN inventory_items i ON s.id = i.sessionId 
        GROUP BY s.id 
        ORDER BY s.createdAt DESC
    """)
    fun getAllSessionSummaries(): Flow<List<InventorySessionSummary>>

    @Query("SELECT * FROM inventory_sessions WHERE id = :sessionId LIMIT 1")
    suspend fun getSessionById(sessionId: String): InventorySession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: InventorySession)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessions(sessions: List<InventorySession>)

    @Delete
    suspend fun deleteSession(session: InventorySession)

    @Query("DELETE FROM inventory_sessions WHERE id = :sessionId")
    suspend fun deleteSessionById(sessionId: String)

    @Query("DELETE FROM inventory_items WHERE sessionId = :sessionId")
    suspend fun deleteItemsForSession(sessionId: String)

    @Query("DELETE FROM inventory_sessions")
    suspend fun deleteAllSessions()

    @Query("SELECT COUNT(*) FROM inventory_sessions")
    suspend fun getSessionCount(): Int

    // === ITEMS FOR SESSION ===
    @Query("SELECT * FROM inventory_items WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun getItemsForSession(sessionId: String): Flow<List<InventoryItem>>

    @Query("SELECT * FROM inventory_items WHERE sessionId = :sessionId")
    suspend fun getItemsListForSession(sessionId: String): List<InventoryItem>

    // For backwards compatibility and migration checks
    @Query("SELECT * FROM inventory_items ORDER BY timestamp ASC")
    fun getAllItems(): Flow<List<InventoryItem>>

    @Query("SELECT * FROM inventory_items ORDER BY timestamp ASC")
    suspend fun getAllItemsList(): List<InventoryItem>

    @Query("SELECT COUNT(*) FROM inventory_items WHERE sessionId = 'legacy_inventory'")
    suspend fun getLegacyItemsCount(): Int

    @Query("SELECT COUNT(*) FROM inventory_items")
    suspend fun getTotalItemsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: InventoryItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<InventoryItem>)

    @Update
    suspend fun updateItem(item: InventoryItem)

    @Delete
    suspend fun deleteItem(item: InventoryItem)

    @Query("DELETE FROM inventory_items WHERE id = :id")
    suspend fun deleteItemById(id: String)

    @Query("DELETE FROM inventory_items")
    suspend fun deleteAllItems()

    // Transaction for restoring backup
    @Transaction
    suspend fun restoreDatabase(
        sessions: List<InventorySession>,
        items: List<InventoryItem>,
        clearExisting: Boolean
    ) {
        if (clearExisting) {
            deleteAllItems()
            deleteAllSessions()
        }
        if (sessions.isNotEmpty()) {
            insertSessions(sessions)
        }
        if (items.isNotEmpty()) {
            insertItems(items)
        }
    }
}
