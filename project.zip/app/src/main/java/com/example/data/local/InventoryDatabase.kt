package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.InventoryItem
import com.example.data.model.InventorySession

@Database(
    entities = [InventorySession::class, InventoryItem::class],
    version = 2,
    exportSchema = false
)
abstract class InventoryDatabase : RoomDatabase() {
    abstract fun inventoryDao(): InventoryDao

    companion object {
        @Volatile
        private var INSTANCE: InventoryDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // 1. Create table inventory_sessions
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `inventory_sessions` (
                        `id` TEXT NOT NULL, 
                        `name` TEXT NOT NULL, 
                        `createdAt` INTEGER NOT NULL, 
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())

                // 2. Add sessionId column to inventory_items
                db.execSQL("ALTER TABLE `inventory_items` ADD COLUMN `sessionId` TEXT NOT NULL DEFAULT 'legacy_inventory'")

                // 3. Create index on sessionId
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_inventory_items_sessionId` ON `inventory_items` (`sessionId`)")

                // 4. Migrate existing items: If there are existing items, create legacy session "الجرد السابق"
                db.execSQL("""
                    INSERT OR IGNORE INTO `inventory_sessions` (`id`, `name`, `createdAt`)
                    SELECT 'legacy_inventory', 'الجرد السابق', COALESCE(MIN(timestamp), CAST(strftime('%s','now') AS INTEGER) * 1000)
                    FROM `inventory_items`
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): InventoryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    InventoryDatabase::class.java,
                    "inventory_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
