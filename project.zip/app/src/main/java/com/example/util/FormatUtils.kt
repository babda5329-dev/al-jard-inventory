package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FormatUtils {
    /**
     * Formats decimal numbers with Western digits (0-9) and exactly two decimal places.
     */
    fun formatDecimal(value: Double): String {
        return String.format(Locale.US, "%.2f", value)
    }

    fun formatCurrency(value: Double): String {
        return "${formatDecimal(value)} ريال يمني"
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.US)
        return sdf.format(Date(timestamp))
    }

    fun formatYear(timestamp: Long = System.currentTimeMillis()): String {
        val sdf = SimpleDateFormat("yyyy", Locale.US)
        return sdf.format(Date(timestamp))
    }

    fun formatTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("hh:mm:ss a", Locale.US)
        return sdf.format(Date(timestamp))
    }

    fun formatFilenameDate(timestamp: Long = System.currentTimeMillis()): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)
        return sdf.format(Date(timestamp))
    }
}
