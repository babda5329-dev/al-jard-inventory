package com.example.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.model.InventoryItem
import java.io.File
import java.io.FileOutputStream

object PdfExporter {

    private const val MM_TO_PT = 72f / 25.4f

    private fun mm(v: Float): Float = v * MM_TO_PT

    /**
     * Exports the inventory list into an A4 PDF document according to the required specifications:
     * - A4 portrait (210 x 297 mm)
     * - 8mm margins
     * - 2 columns per page (30 items right column, 30 items left column)
     * - Column widths: index 9mm, name 32mm, quantity 14mm, price 17mm, total 21mm
     * - High-contrast headers, clear borders for printing, and optional dark mode
     * - Alternating row backgrounds and sharp lines
     * - Blue divider at the page center
     * - Final page: 90x10mm centered blue rounded box with "الإجمالي الكلي: [total] ريال يمني"
     * - Arabic shaping and RTL support
     */
    fun exportToPdf(
        context: Context,
        items: List<InventoryItem>,
        isDarkMode: Boolean = false,
        sessionName: String? = null
    ): Result<File> {
        return try {
            val totalSum = items.sumOf { it.total }

            val exportTimestamp = System.currentTimeMillis()
            val exportYear = FormatUtils.formatYear(exportTimestamp)

            // Inventory year: based on the inventory items' timestamps (or export year if empty/default)
            val inventoryTimestamp = if (items.isNotEmpty()) {
                // Use the latest or predominant timestamp of the inventory items
                items.maxOf { it.timestamp }
            } else {
                exportTimestamp
            }
            val inventoryYear = FormatUtils.formatYear(inventoryTimestamp)

            val pageWidthPt = mm(210f).toInt()
            val pageHeightPt = mm(297f).toInt()

            val pdfDocument = PdfDocument()

            // Try to load Cairo font or fallback to sans-serif
            val cairoTypeface = try {
                ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.DEFAULT
            } catch (_: Exception) {
                Typeface.DEFAULT
            }

            val cairoBoldTypeface = Typeface.create(cairoTypeface, Typeface.BOLD)

            // Theme colors
            val pageBgColor = if (isDarkMode) Color.parseColor("#0F172A") else Color.WHITE
            val headerBgColor = if (isDarkMode) Color.parseColor("#0284C7") else Color.parseColor("#1565C0")
            // Enhanced borders for crisp, sharp printouts
            val outerBorderColor = if (isDarkMode) Color.parseColor("#475569") else Color.parseColor("#1E293B")
            val innerGridColor = if (isDarkMode) Color.parseColor("#334155") else Color.parseColor("#64748B")
            val dividerColor = if (isDarkMode) Color.parseColor("#38BDF8") else Color.parseColor("#1E40AF")
            val rowPrimaryColor = if (isDarkMode) Color.parseColor("#1E293B") else Color.WHITE
            val rowAltColor = if (isDarkMode) Color.parseColor("#0F172A") else Color.parseColor("#F1F5F9")
            val headerTextColor = Color.WHITE
            val cellTextColor = if (isDarkMode) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
            val titleTextColor = if (isDarkMode) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
            val subTextColor = if (isDarkMode) Color.parseColor("#94A3B8") else Color.parseColor("#334155")
            val totalBoxColor = if (isDarkMode) Color.parseColor("#0284C7") else Color.parseColor("#1565C0")
            val totalBoxBorderColor = if (isDarkMode) Color.parseColor("#38BDF8") else Color.parseColor("#0D47A1")

            // Paints
            val pageBgPaint = Paint().apply {
                color = pageBgColor
                style = Paint.Style.FILL
            }

            val headerPaint = Paint().apply {
                color = headerBgColor
                style = Paint.Style.FILL
            }

            val outerBorderPaint = Paint().apply {
                color = outerBorderColor
                style = Paint.Style.STROKE
                strokeWidth = mm(0.45f) // Bold outer frame for print definition
                isAntiAlias = true
            }

            val innerGridPaint = Paint().apply {
                color = innerGridColor
                style = Paint.Style.STROKE
                strokeWidth = mm(0.28f) // Crisp inner grid lines that won't smudge or disappear
                isAntiAlias = true
            }

            val centerDividerPaint = Paint().apply {
                color = dividerColor
                style = Paint.Style.STROKE
                strokeWidth = mm(0.8f)
                isAntiAlias = true
            }

            val whiteRowPaint = Paint().apply {
                color = rowPrimaryColor
                style = Paint.Style.FILL
            }

            val altRowPaint = Paint().apply {
                color = rowAltColor
                style = Paint.Style.FILL
            }

            val headerTextPaint = TextPaint().apply {
                color = headerTextColor
                textSize = 9.5f
                typeface = cairoBoldTypeface
                isAntiAlias = true
            }

            val cellTextPaint = TextPaint().apply {
                color = cellTextColor
                textSize = 8.5f
                typeface = cairoTypeface
                isAntiAlias = true
            }

            val titleTextPaint = TextPaint().apply {
                color = titleTextColor
                textSize = 14f
                typeface = cairoBoldTypeface
                isAntiAlias = true
            }

            val subTextPaint = TextPaint().apply {
                color = subTextColor
                textSize = 8.5f
                typeface = cairoTypeface
                isAntiAlias = true
            }

            val headerLinePaint = Paint().apply {
                color = if (isDarkMode) Color.parseColor("#334155") else Color.parseColor("#CBD5E1")
                style = Paint.Style.STROKE
                strokeWidth = mm(0.35f)
                isAntiAlias = true
            }

            val totalBoxPaint = Paint().apply {
                color = totalBoxColor
                style = Paint.Style.FILL
                isAntiAlias = true
            }

            val totalBoxBorderPaint = Paint().apply {
                color = totalBoxBorderColor
                style = Paint.Style.STROKE
                strokeWidth = mm(0.5f)
                isAntiAlias = true
            }

            val totalBoxTextPaint = TextPaint().apply {
                color = Color.WHITE
                textSize = 10.5f
                typeface = cairoBoldTypeface
                isAntiAlias = true
            }

            val footerTextPaint = TextPaint().apply {
                color = if (isDarkMode) Color.parseColor("#64748B") else Color.parseColor("#94A3B8")
                textSize = 7.5f
                typeface = cairoTypeface
                isAntiAlias = true
            }

            val itemsPerPage = 60
            val totalPages = ((items.size + itemsPerPage - 1) / itemsPerPage).coerceAtLeast(1)

            val marginPt = mm(8f)
            val headerHeightPt = mm(11f)
            val rowHeightPt = mm(7.2f)

            // Table column widths in mm:
            // RTL: Index (9mm), Name (32mm), Quantity (14mm), Price (17mm), Total (21mm)
            val colTotalMm = 21f
            val colPriceMm = 17f
            val colQtyMm = 14f
            val colNameMm = 32f
            val colIdxMm = 9f
            val tableWidthMm = colIdxMm + colNameMm + colQtyMm + colPriceMm + colTotalMm // 93mm

            val tableWidthPt = mm(tableWidthMm)
            val centerGapMm = 8f
            val leftTableLeftPt = marginPt
            val rightTableLeftPt = marginPt + tableWidthPt + mm(centerGapMm)

            val tableTopPt = mm(26f)
            val tableBottomPt = tableTopPt + headerHeightPt + (rowHeightPt * 30f)

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPt, pageHeightPt, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                // Fill page background
                canvas.drawRect(0f, 0f, pageWidthPt.toFloat(), pageHeightPt.toFloat(), pageBgPaint)

                // 1. Draw Page Title & Header Banner
                drawPageHeader(
                    canvas = canvas,
                    pageWidth = pageWidthPt.toFloat(),
                    marginPt = marginPt,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages,
                    totalItemsCount = items.size,
                    inventoryYear = inventoryYear,
                    exportYear = exportYear,
                    sessionName = sessionName,
                    titlePaint = titleTextPaint,
                    subPaint = subTextPaint,
                    headerLinePaint = headerLinePaint,
                    isDarkMode = isDarkMode
                )

                // 2. Draw Center Blue Divider
                val centerX = pageWidthPt / 2f
                canvas.drawLine(centerX, tableTopPt, centerX, tableBottomPt, centerDividerPaint)

                // 3. Slice items for this page
                val pageStartIdx = pageIndex * itemsPerPage
                val pageItems = items.drop(pageStartIdx).take(itemsPerPage)

                // Right column: items 1–30 (relative to page)
                val rightItems = pageItems.take(30)
                // Left column: items 31–60 (relative to page)
                val leftItems = pageItems.drop(30).take(30)

                // Draw Right Table (Arabic 1st column: Items 1 to 30)
                drawSubTable(
                    canvas = canvas,
                    startX = rightTableLeftPt,
                    topY = tableTopPt,
                    items = rightItems,
                    startItemNumber = pageStartIdx + 1,
                    headerHeight = headerHeightPt,
                    rowHeight = rowHeightPt,
                    headerPaint = headerPaint,
                    outerBorderPaint = outerBorderPaint,
                    innerGridPaint = innerGridPaint,
                    whiteRowPaint = whiteRowPaint,
                    altRowPaint = altRowPaint,
                    headerTextPaint = headerTextPaint,
                    cellTextPaint = cellTextPaint
                )

                // Draw Left Table (Arabic 2nd column: Items 31 to 60)
                drawSubTable(
                    canvas = canvas,
                    startX = leftTableLeftPt,
                    topY = tableTopPt,
                    items = leftItems,
                    startItemNumber = pageStartIdx + 31,
                    headerHeight = headerHeightPt,
                    rowHeight = rowHeightPt,
                    headerPaint = headerPaint,
                    outerBorderPaint = outerBorderPaint,
                    innerGridPaint = innerGridPaint,
                    whiteRowPaint = whiteRowPaint,
                    altRowPaint = altRowPaint,
                    headerTextPaint = headerTextPaint,
                    cellTextPaint = cellTextPaint
                )

                // 4. On final page, draw centered rounded box: 90x10mm
                if (pageIndex == totalPages - 1) {
                    val boxWidthPt = mm(90f)
                    val boxHeightPt = mm(10f)
                    val boxLeftPt = (pageWidthPt - boxWidthPt) / 2f
                    val boxTopPt = tableBottomPt + mm(5f)
                    val boxRect = RectF(boxLeftPt, boxTopPt, boxLeftPt + boxWidthPt, boxTopPt + boxHeightPt)

                    val cornerRadiusPt = mm(2.5f)
                    canvas.drawRoundRect(boxRect, cornerRadiusPt, cornerRadiusPt, totalBoxPaint)
                    canvas.drawRoundRect(boxRect, cornerRadiusPt, cornerRadiusPt, totalBoxBorderPaint)

                    val totalText = "الإجمالي الكلي: ${FormatUtils.formatDecimal(totalSum)} ريال يمني"
                    drawCenteredText(
                        canvas = canvas,
                        text = totalText,
                        x = boxLeftPt,
                        y = boxTopPt,
                        width = boxWidthPt,
                        height = boxHeightPt,
                        paint = totalBoxTextPaint
                    )
                }

                // 5. Draw Footer at the bottom of the page
                val footerY = pageHeightPt - mm(4.5f)
                val footerText = "الجرد المخزني صادر عام $inventoryYear | تم التصدير في عام $exportYear | صفحة ${pageIndex + 1} من $totalPages"
                drawCenteredText(
                    canvas = canvas,
                    text = footerText,
                    x = marginPt,
                    y = footerY,
                    width = pageWidthPt - (marginPt * 2f),
                    height = mm(4f),
                    paint = footerTextPaint
                )

                pdfDocument.finishPage(page)
            }

            // Save to file
            val exportDir = File(context.filesDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()

            val prefix = if (isDarkMode) "inventory_dark" else "inventory"
            val filename = "${prefix}_${FormatUtils.formatFilenameDate()}.pdf"
            val file = File(exportDir, filename)

            FileOutputStream(file).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            Result.success(file)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun drawPageHeader(
        canvas: Canvas,
        pageWidth: Float,
        marginPt: Float,
        pageIndex: Int,
        totalPages: Int,
        totalItemsCount: Int,
        inventoryYear: String,
        exportYear: String,
        sessionName: String?,
        titlePaint: TextPaint,
        subPaint: TextPaint,
        headerLinePaint: Paint,
        isDarkMode: Boolean
    ) {
        val themeLabel = if (isDarkMode) " (الوضع الليلي)" else ""
        val title = if (!sessionName.isNullOrBlank()) {
            "جرد: $sessionName صادر في عام $inventoryYear$themeLabel"
        } else {
            "الجرد المخزني صادر في عام $inventoryYear$themeLabel"
        }
        val subtitle = "تاريخ التصدير: ${FormatUtils.formatDate(System.currentTimeMillis())} (عام $exportYear) | عدد الأصناف: $totalItemsCount صنف | الصفحة $pageIndex من $totalPages"

        drawRtlText(
            canvas = canvas,
            text = title,
            x = marginPt,
            y = mm(7.5f),
            width = pageWidth - (marginPt * 2f),
            paint = titlePaint,
            align = Layout.Alignment.ALIGN_OPPOSITE
        )

        drawRtlText(
            canvas = canvas,
            text = subtitle,
            x = marginPt,
            y = mm(16f),
            width = pageWidth - (marginPt * 2f),
            paint = subPaint,
            align = Layout.Alignment.ALIGN_OPPOSITE
        )

        // Divider line below header
        canvas.drawLine(marginPt, mm(22.5f), pageWidth - marginPt, mm(22.5f), headerLinePaint)
    }

    private fun drawSubTable(
        canvas: Canvas,
        startX: Float,
        topY: Float,
        items: List<InventoryItem>,
        startItemNumber: Int,
        headerHeight: Float,
        rowHeight: Float,
        headerPaint: Paint,
        outerBorderPaint: Paint,
        innerGridPaint: Paint,
        whiteRowPaint: Paint,
        altRowPaint: Paint,
        headerTextPaint: TextPaint,
        cellTextPaint: TextPaint
    ) {
        val colTotalPt = mm(21f)
        val colPricePt = mm(17f)
        val colQtyPt = mm(14f)
        val colNamePt = mm(32f)
        val colIdxPt = mm(9f)
        val totalWidthPt = colTotalPt + colPricePt + colQtyPt + colNamePt + colIdxPt

        // Coordinates from left to right:
        val xTotal = startX
        val xPrice = xTotal + colTotalPt
        val xQty = xPrice + colPricePt
        val xName = xQty + colQtyPt
        val xIdx = xName + colNamePt

        // 1. Draw Header
        val headerRect = RectF(startX, topY, startX + totalWidthPt, topY + headerHeight)
        canvas.drawRect(headerRect, headerPaint)

        // Draw header vertical divider lines
        canvas.drawLine(xPrice, topY, xPrice, topY + headerHeight, innerGridPaint)
        canvas.drawLine(xQty, topY, xQty, topY + headerHeight, innerGridPaint)
        canvas.drawLine(xName, topY, xName, topY + headerHeight, innerGridPaint)
        canvas.drawLine(xIdx, topY, xIdx, topY + headerHeight, innerGridPaint)

        // Draw Header Titles (centered in each column)
        drawCenteredText(canvas, "#", xIdx, topY, colIdxPt, headerHeight, headerTextPaint)
        drawCenteredText(canvas, "اسم الصنف", xName, topY, colNamePt, headerHeight, headerTextPaint)
        drawCenteredText(canvas, "الكمية", xQty, topY, colQtyPt, headerHeight, headerTextPaint)
        drawCenteredText(canvas, "السعر (ريال)", xPrice, topY, colPricePt, headerHeight, headerTextPaint)
        drawCenteredText(canvas, "الإجمالي", xTotal, topY, colTotalPt, headerHeight, headerTextPaint)

        // 2. Draw 30 Rows with sharp borders and alternating background
        var currentY = topY + headerHeight
        for (i in 0 until 30) {
            val rowRect = RectF(startX, currentY, startX + totalWidthPt, currentY + rowHeight)
            val fillPaint = if (i % 2 == 0) whiteRowPaint else altRowPaint
            canvas.drawRect(rowRect, fillPaint)

            // Inner horizontal divider line
            canvas.drawLine(startX, currentY, startX + totalWidthPt, currentY, innerGridPaint)

            // Inner vertical column dividers
            canvas.drawLine(xPrice, currentY, xPrice, currentY + rowHeight, innerGridPaint)
            canvas.drawLine(xQty, currentY, xQty, currentY + rowHeight, innerGridPaint)
            canvas.drawLine(xName, currentY, xName, currentY + rowHeight, innerGridPaint)
            canvas.drawLine(xIdx, currentY, xIdx, currentY + rowHeight, innerGridPaint)

            if (i < items.size) {
                val item = items[i]
                val itemNumber = startItemNumber + i

                val truncatedName = if (item.name.length > 18) {
                    item.name.substring(0, 18)
                } else {
                    item.name
                }

                drawCenteredText(canvas, itemNumber.toString(), xIdx, currentY, colIdxPt, rowHeight, cellTextPaint)
                drawCenteredText(canvas, truncatedName, xName, currentY, colNamePt, rowHeight, cellTextPaint)
                drawCenteredText(canvas, FormatUtils.formatDecimal(item.quantity), xQty, currentY, colQtyPt, rowHeight, cellTextPaint)
                drawCenteredText(canvas, FormatUtils.formatDecimal(item.price), xPrice, currentY, colPricePt, rowHeight, cellTextPaint)
                drawCenteredText(canvas, FormatUtils.formatDecimal(item.total), xTotal, currentY, colTotalPt, rowHeight, cellTextPaint)
            }

            currentY += rowHeight
        }

        // 3. Draw bold outer border frame around the entire table for crisp print edges
        val fullTableRect = RectF(startX, topY, startX + totalWidthPt, topY + headerHeight + (rowHeight * 30f))
        canvas.drawRect(fullTableRect, outerBorderPaint)
    }

    private fun drawCenteredText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        width: Float,
        height: Float,
        paint: TextPaint
    ) {
        val safeWidth = width.toInt().coerceAtLeast(1)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, safeWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .setMaxLines(1)
            .setEllipsize(TextUtils.TruncateAt.END)
            .build()

        val textHeight = layout.height
        val offsetY = y + ((height - textHeight) / 2f).coerceAtLeast(0f)

        canvas.save()
        canvas.translate(x, offsetY)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawRtlText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        width: Float,
        paint: TextPaint,
        align: Layout.Alignment = Layout.Alignment.ALIGN_OPPOSITE
    ) {
        val safeWidth = width.toInt().coerceAtLeast(1)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, safeWidth)
            .setAlignment(align)
            .setIncludePad(false)
            .setMaxLines(1)
            .build()

        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }
}
