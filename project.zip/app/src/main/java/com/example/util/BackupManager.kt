package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.model.BackupItem
import com.example.data.model.BackupSession
import com.example.data.model.InventoryBackupData
import com.example.data.model.InventoryItem
import com.example.data.model.InventorySession
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object BackupManager {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(InventoryBackupData::class.java).indent("  ")

    /**
     * Converts sessions and items to a JSON string.
     */
    fun createBackupJson(
        sessions: List<InventorySession>,
        items: List<InventoryItem>
    ): String {
        val backupData = InventoryBackupData(
            version = 1,
            exportedAt = System.currentTimeMillis(),
            appName = "الجرد المخزني",
            sessions = sessions.map { s ->
                BackupSession(
                    id = s.id,
                    name = s.name,
                    createdAt = s.createdAt
                )
            },
            items = items.map { i ->
                BackupItem(
                    id = i.id,
                    sessionId = i.sessionId,
                    name = i.name,
                    quantity = i.quantity,
                    price = i.price,
                    total = i.total,
                    details = i.details,
                    timestamp = i.timestamp
                )
            }
        )
        return adapter.toJson(backupData)
    }

    /**
     * Exports database to a local file in internal/external app files directory.
     * Returns the created file.
     */
    fun exportBackupToFile(
        context: Context,
        sessions: List<InventorySession>,
        items: List<InventoryItem>
    ): Result<File> {
        return try {
            val jsonString = createBackupJson(sessions, items)
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "jard_backup_$timestamp.json"

            // Save in cache/files dir so FileProvider can share it
            val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
            val file = File(backupDir, fileName)

            FileOutputStream(file).use { fos ->
                OutputStreamWriter(fos, Charsets.UTF_8).use { writer ->
                    writer.write(jsonString)
                }
            }

            Result.success(file)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Exports database directly to a user-selected SAF Uri (from CreateDocument launcher).
     */
    fun exportBackupToUri(
        context: Context,
        uri: Uri,
        sessions: List<InventorySession>,
        items: List<InventoryItem>
    ): Result<Unit> {
        return try {
            val jsonString = createBackupJson(sessions, items)
            val outputStream = context.contentResolver.openOutputStream(uri)
                ?: return Result.failure(IllegalStateException("تعذر فتح مسار الملف للحفظ"))

            outputStream.use { os ->
                OutputStreamWriter(os, Charsets.UTF_8).use { writer ->
                    writer.write(jsonString)
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Parses and validates a JSON string into sessions and items entities.
     */
    fun parseBackupJson(jsonString: String): Result<Pair<List<InventorySession>, List<InventoryItem>>> {
        return try {
            val backupData = adapter.fromJson(jsonString)
                ?: return Result.failure(IllegalArgumentException("ملف النسخة الاحتياطية فارغ أو غير صالح"))

            // Convert backup sessions
            val sessionsMap = mutableMapOf<String, InventorySession>()
            for (bs in backupData.sessions) {
                if (bs.id.isNotBlank() && bs.name.isNotBlank()) {
                    sessionsMap[bs.id] = InventorySession(
                        id = bs.id,
                        name = bs.name,
                        createdAt = if (bs.createdAt > 0L) bs.createdAt else System.currentTimeMillis()
                    )
                }
            }

            // Convert backup items
            val itemsList = mutableListOf<InventoryItem>()
            for (bi in backupData.items) {
                if (bi.name.isNotBlank()) {
                    val targetSessionId = if (bi.sessionId.isNotBlank()) {
                        bi.sessionId
                    } else {
                        "legacy_inventory"
                    }

                    // If session doesn't exist in sessions list, ensure an entry exists
                    if (!sessionsMap.containsKey(targetSessionId)) {
                        sessionsMap[targetSessionId] = InventorySession(
                            id = targetSessionId,
                            name = if (targetSessionId == "legacy_inventory") "الجرد السابق" else "جرد مسترجع",
                            createdAt = System.currentTimeMillis()
                        )
                    }

                    val totalCalculated = if (bi.total > 0) bi.total else (bi.quantity * bi.price)
                    itemsList.add(
                        InventoryItem(
                            id = if (bi.id.isNotBlank()) bi.id else UUID.randomUUID().toString(),
                            sessionId = targetSessionId,
                            name = bi.name,
                            quantity = bi.quantity,
                            price = bi.price,
                            total = totalCalculated,
                            details = bi.details,
                            timestamp = if (bi.timestamp > 0L) bi.timestamp else System.currentTimeMillis()
                        )
                    )
                }
            }

            // If there are no sessions but items exist, create default session
            if (sessionsMap.isEmpty() && itemsList.isNotEmpty()) {
                val defaultSessionId = UUID.randomUUID().toString()
                sessionsMap[defaultSessionId] = InventorySession(
                    id = defaultSessionId,
                    name = "جرد مسترجع",
                    createdAt = System.currentTimeMillis()
                )
            }

            Result.success(Pair(sessionsMap.values.toList(), itemsList))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Reads JSON from a Uri (via SAF OpenDocument launcher) and parses it.
     */
    fun importBackupFromUri(
        context: Context,
        uri: Uri
    ): Result<Pair<List<InventorySession>, List<InventoryItem>>> {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return Result.failure(IllegalStateException("تعذر فتح ملف النسخة الاحتياطية"))

            val jsonString = inputStream.use { stream ->
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                    reader.readText()
                }
            }

            parseBackupJson(jsonString)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
