package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InventoryItem
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.BorderStroke
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueDark
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.SuccessGreen
import com.example.util.FormatUtils

@Composable
fun InventoryTableCard(
    items: List<InventoryItem>,
    editingItemId: String?,
    editName: String,
    onEditNameChange: (String) -> Unit,
    editQuantity: String,
    onEditQuantityChange: (String) -> Unit,
    editPrice: String,
    onEditPriceChange: (String) -> Unit,
    editDetails: String,
    onEditDetailsChange: (String) -> Unit,
    editError: String?,
    onStartEdit: (InventoryItem) -> Unit,
    onSaveEdit: (InventoryItem) -> Unit,
    onCancelEdit: () -> Unit,
    onDeleteItem: (InventoryItem) -> Unit,
    onExportPdf: () -> Unit,
    isExporting: Boolean,
    searchQuery: String = "",
    onSearchQueryChange: (String) -> Unit = {},
    onClearSearchQuery: () -> Unit = {},
    totalItemsCount: Int = items.size,
    modifier: Modifier = Modifier
) {
    val totalSum = items.sumOf { it.total }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("inventory_table_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderStroke),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            // Card Title and PDF Export Button Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FormatListBulleted,
                        contentDescription = null,
                        tint = PrimaryBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "قائمة الأصناف",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    // Items Count Badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PrimaryBlueLight,
                        modifier = Modifier.testTag("items_count_badge")
                    ) {
                        val countText = if (searchQuery.isNotEmpty()) {
                            "${items.size} / $totalItemsCount"
                        } else {
                            "${items.size}"
                        }
                        Text(
                            text = countText,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = PrimaryBlueDark
                        )
                    }
                }

                // PDF Export Button
                Button(
                    onClick = onExportPdf,
                    enabled = items.isNotEmpty() && !isExporting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentTeal,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("button_export_pdf")
                ) {
                    if (isExporting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("جاري التصدير...", fontSize = 13.sp)
                    } else {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "تصدير PDF",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تصدير PDF",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar Field above items list
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = {
                    Text(
                        text = "بحث عن صنف بالاسم...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF94A3B8)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "بحث",
                        tint = PrimaryBlue,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = onClearSearchQuery,
                            modifier = Modifier.testTag("button_clear_search")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "مسح البحث",
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(
                    textDirection = TextDirection.ContentOrRtl,
                    textAlign = TextAlign.Start,
                    fontSize = 14.sp
                ),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = BorderStroke,
                    focusedContainerColor = Color(0xFFF8FAFC),
                    unfocusedContainerColor = Color(0xFFF8FAFC)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .testTag("input_search_item")
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (items.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 36.dp)
                        .testTag("empty_inventory_message"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isNotEmpty()) {
                            "لا توجد أصناف مطابقة للبحث \"$searchQuery\""
                        } else {
                            "لا توجد أصناف مسجلة. قم بإضافة صنف جديد للبدء."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // Scrollable Table Container
                val scrollState = rememberScrollState()

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState)
                ) {
                    // Table Header Row
                    TableHeaderRow()

                    HorizontalDivider(color = BorderStroke, thickness = 1.dp)

                    // Table Items Rows inside LazyColumn
                    val tableListHeight = (items.size * 52).coerceIn(104, 450).dp

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(tableListHeight)
                            .testTag("inventory_items_lazy_column"),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        itemsIndexed(
                            items = items,
                            key = { _, item -> item.id }
                        ) { index, item ->
                            val isEditing = editingItemId == item.id
                            val isEven = index % 2 == 0

                            if (isEditing) {
                                TableEditRow(
                                    item = item,
                                    editName = editName,
                                    onEditNameChange = onEditNameChange,
                                    editQuantity = editQuantity,
                                    onEditQuantityChange = onEditQuantityChange,
                                    editPrice = editPrice,
                                    onEditPriceChange = onEditPriceChange,
                                    editDetails = editDetails,
                                    onEditDetailsChange = onEditDetailsChange,
                                    editError = editError,
                                    onSave = { onSaveEdit(item) },
                                    onCancel = onCancelEdit
                                )
                            } else {
                                TableItemRow(
                                    index = index + 1,
                                    item = item,
                                    isEven = isEven,
                                    onStartEdit = { onStartEdit(item) },
                                    onDelete = { onDeleteItem(item) }
                                )
                            }

                            HorizontalDivider(color = BorderStroke, thickness = 0.5.dp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Total Sum
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("total_summary_box"),
                    shape = RoundedCornerShape(12.dp),
                    color = PrimaryBlueLight,
                    border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "الإجمالي الكلي:",
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp),
                            color = PrimaryBlueDark,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "${FormatUtils.formatDecimal(totalSum)} ريال يمني",
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 19.sp),
                            color = PrimaryBlueDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// Column widths in dp
private val colWidthIndex = 50.dp
private val colWidthName = 160.dp
private val colWidthQty = 90.dp
private val colWidthPrice = 110.dp
private val colWidthTotal = 120.dp
private val colWidthDetails = 150.dp
private val colWidthDate = 100.dp
private val colWidthTime = 110.dp
private val colWidthActions = 100.dp

@Composable
private fun TableHeaderRow() {
    Row(
        modifier = Modifier
            .background(Color(0xFFF1F5F9))
            .padding(vertical = 12.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TableCellText(text = "#", width = colWidthIndex, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "اسم الصنف", width = colWidthName, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "الكمية", width = colWidthQty, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "السعر (ريال)", width = colWidthPrice, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "الإجمالي (ريال)", width = colWidthTotal, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "التفاصيل", width = colWidthDetails, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "التاريخ", width = colWidthDate, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "الوقت", width = colWidthTime, isHeader = true, textAlign = TextAlign.Right)
        TableCellText(text = "إجراءات", width = colWidthActions, isHeader = true, textAlign = TextAlign.Center)
    }
}

@Composable
private fun TableItemRow(
    index: Int,
    item: InventoryItem,
    isEven: Boolean,
    onStartEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val bgColor = if (isEven) Color.White else Color(0xFFF8FAFC)

    Row(
        modifier = Modifier
            .background(bgColor)
            .padding(vertical = 10.dp, horizontal = 16.dp)
            .testTag("row_item_${item.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TableCellText(text = "$index", width = colWidthIndex, textAlign = TextAlign.Right)
        TableCellText(text = item.name, width = colWidthName, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Right)
        TableCellText(text = FormatUtils.formatDecimal(item.quantity), width = colWidthQty, textAlign = TextAlign.Right)
        TableCellText(text = FormatUtils.formatDecimal(item.price), width = colWidthPrice, textAlign = TextAlign.Right)
        TableCellText(
            text = FormatUtils.formatDecimal(item.total),
            width = colWidthTotal,
            fontWeight = FontWeight.Bold,
            textColor = PrimaryBlueDark,
            textAlign = TextAlign.Right
        )
        TableCellText(text = item.details ?: "-", width = colWidthDetails, textAlign = TextAlign.Right)
        TableCellText(text = FormatUtils.formatDate(item.timestamp), width = colWidthDate, textAlign = TextAlign.Right)
        TableCellText(text = FormatUtils.formatTime(item.timestamp), width = colWidthTime, textAlign = TextAlign.Right)

        // Actions: Edit and Delete
        Row(
            modifier = Modifier.width(colWidthActions),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onStartEdit,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("button_edit_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "تعديل",
                    tint = PrimaryBlue,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("button_delete_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "حذف",
                    tint = ErrorRed,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun TableEditRow(
    item: InventoryItem,
    editName: String,
    onEditNameChange: (String) -> Unit,
    editQuantity: String,
    onEditQuantityChange: (String) -> Unit,
    editPrice: String,
    onEditPriceChange: (String) -> Unit,
    editDetails: String,
    onEditDetailsChange: (String) -> Unit,
    editError: String?,
    onSave: () -> Unit,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .background(Color(0xFFEFF6FF))
            .padding(vertical = 10.dp, horizontal = 16.dp)
            .testTag("row_edit_${item.id}")
    ) {
        if (editError != null) {
            Text(
                text = editError,
                color = ErrorRed,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Index placeholder
            Box(
                modifier = Modifier.width(colWidthIndex),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Name
            OutlinedTextField(
                value = editName,
                onValueChange = onEditNameChange,
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(
                    textDirection = TextDirection.ContentOrRtl,
                    textAlign = TextAlign.Right,
                    fontSize = 13.sp
                ),
                modifier = Modifier
                    .width(colWidthName)
                    .padding(horizontal = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = BorderStroke
                )
            )

            // Quantity
            OutlinedTextField(
                value = editQuantity,
                onValueChange = onEditQuantityChange,
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(
                    textDirection = TextDirection.ContentOrRtl,
                    textAlign = TextAlign.Right,
                    fontSize = 13.sp
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .width(colWidthQty)
                    .padding(horizontal = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = BorderStroke
                )
            )

            // Price
            OutlinedTextField(
                value = editPrice,
                onValueChange = onEditPriceChange,
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(
                    textDirection = TextDirection.ContentOrRtl,
                    textAlign = TextAlign.Right,
                    fontSize = 13.sp
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .width(colWidthPrice)
                    .padding(horizontal = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = BorderStroke
                )
            )

            // Calculated total preview
            val q = editQuantity.toDoubleOrNull() ?: 0.0
            val p = editPrice.toDoubleOrNull() ?: 0.0
            val calcTotal = q * p
            TableCellText(
                text = FormatUtils.formatDecimal(calcTotal),
                width = colWidthTotal,
                fontWeight = FontWeight.Bold,
                textColor = PrimaryBlueDark,
                textAlign = TextAlign.Right
            )

            // Details
            OutlinedTextField(
                value = editDetails,
                onValueChange = onEditDetailsChange,
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(
                    textDirection = TextDirection.ContentOrRtl,
                    textAlign = TextAlign.Right,
                    fontSize = 13.sp
                ),
                modifier = Modifier
                    .width(colWidthDetails)
                    .padding(horizontal = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = BorderStroke
                )
            )

            // Date / Time (static)
            TableCellText(text = FormatUtils.formatDate(item.timestamp), width = colWidthDate, textAlign = TextAlign.Right)
            TableCellText(text = FormatUtils.formatTime(item.timestamp), width = colWidthTime, textAlign = TextAlign.Right)

            // Save and Cancel buttons
            Row(
                modifier = Modifier.width(colWidthActions),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onSave,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("button_save_edit_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "حفظ",
                        tint = SuccessGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = onCancel,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("button_cancel_edit_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إلغاء",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TableCellText(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    fontWeight: FontWeight? = null,
    textColor: Color? = null,
    textAlign: TextAlign = TextAlign.Right
) {
    Text(
        text = text,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 8.dp),
        textAlign = textAlign,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        style = if (isHeader) {
            MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFF334155),
                textDirection = TextDirection.ContentOrRtl
            )
        } else {
            MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.sp,
                fontWeight = fontWeight ?: FontWeight.Normal,
                color = textColor ?: Color(0xFF1E293B),
                textDirection = TextDirection.ContentOrRtl
            )
        }
    )
}
