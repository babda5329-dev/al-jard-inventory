package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.FormFieldFocus
import com.example.ui.theme.BorderStroke
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenLight
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.theme.TextMuted
import com.example.util.FormatUtils

@Composable
fun AddItemCard(
    name: String,
    onNameChange: (String) -> Unit,
    nameError: String?,
    quantity: String,
    onQuantityChange: (String) -> Unit,
    quantityError: String?,
    price: String,
    onPriceChange: (String) -> Unit,
    priceError: String?,
    details: String,
    onDetailsChange: (String) -> Unit,
    focusTarget: FormFieldFocus,
    onFocusHandled: () -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val nameFocusRequester = remember { FocusRequester() }
    val quantityFocusRequester = remember { FocusRequester() }
    val priceFocusRequester = remember { FocusRequester() }
    val detailsFocusRequester = remember { FocusRequester() }

    LaunchedEffect(focusTarget) {
        when (focusTarget) {
            FormFieldFocus.NAME -> {
                nameFocusRequester.requestFocus()
                onFocusHandled()
            }
            FormFieldFocus.QUANTITY -> {
                quantityFocusRequester.requestFocus()
                onFocusHandled()
            }
            FormFieldFocus.PRICE -> {
                priceFocusRequester.requestFocus()
                onFocusHandled()
            }
            FormFieldFocus.DETAILS -> {
                detailsFocusRequester.requestFocus()
                onFocusHandled()
            }
            FormFieldFocus.NONE -> {}
        }
    }

    // Live total computation for instant user feedback
    val qtyNum = quantity.toDoubleOrNull()
    val priceNum = price.toDoubleOrNull()
    val calculatedTotal = if (qtyNum != null && priceNum != null && qtyNum > 0 && priceNum > 0) {
        qtyNum * priceNum
    } else {
        null
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("add_item_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderStroke),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PrimaryBlueLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AddCircleOutline,
                        contentDescription = null,
                        tint = PrimaryBlue,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "إضافة صنف جديد",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "أدخل بيانات الصنف بالترتيب المتسلسل (الاسم، الكمية، السعر، الملاحظات)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Step 1: اسم الصنف (Item Name)
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    StepNumberBadge(number = "1")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "اسم الصنف",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextDarkPrimary
                    )
                    Text(
                        text = " *",
                        color = ErrorRed,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = onNameChange,
                    placeholder = { Text("أدخل اسم الصنف (مثال: أرز، سكر، زيت...)") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = null,
                            tint = if (nameError != null) ErrorRed else PrimaryBlue
                        )
                    },
                    isError = nameError != null,
                    supportingText = nameError?.let { { Text(it, color = ErrorRed, textAlign = TextAlign.Start) } },
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        textDirection = TextDirection.ContentOrRtl,
                        textAlign = TextAlign.Start
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { quantityFocusRequester.requestFocus() }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = BorderStroke
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(nameFocusRequester)
                        .testTag("input_item_name")
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Step 2: الكمية (Quantity)
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    StepNumberBadge(number = "2")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الكمية",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextDarkPrimary
                    )
                    Text(
                        text = " *",
                        color = ErrorRed,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedTextField(
                    value = quantity,
                    onValueChange = onQuantityChange,
                    placeholder = { Text("أدخل الكمية (مثال: 10 أو 2.5)") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Inventory,
                            contentDescription = null,
                            tint = if (quantityError != null) ErrorRed else PrimaryBlue
                        )
                    },
                    isError = quantityError != null,
                    supportingText = quantityError?.let { { Text(it, color = ErrorRed, textAlign = TextAlign.Start) } },
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        textDirection = TextDirection.ContentOrRtl,
                        textAlign = TextAlign.Start
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { priceFocusRequester.requestFocus() }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = BorderStroke
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(quantityFocusRequester)
                        .testTag("input_item_quantity")
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Step 3: السعر (Price)
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    StepNumberBadge(number = "3")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "السعر (ريال يمني)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextDarkPrimary
                    )
                    Text(
                        text = " *",
                        color = ErrorRed,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedTextField(
                    value = price,
                    onValueChange = onPriceChange,
                    placeholder = { Text("أدخل سعر الوحدة بالريال اليمني (مثال: 1500)") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Payments,
                            contentDescription = null,
                            tint = if (priceError != null) ErrorRed else PrimaryBlue
                        )
                    },
                    isError = priceError != null,
                    supportingText = priceError?.let { { Text(it, color = ErrorRed, textAlign = TextAlign.Start) } },
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        textDirection = TextDirection.ContentOrRtl,
                        textAlign = TextAlign.Start
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { detailsFocusRequester.requestFocus() }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = BorderStroke
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(priceFocusRequester)
                        .testTag("input_item_price")
                )
            }

            // Live Calculated Total Banner (Visible smoothly when Quantity and Price are filled)
            AnimatedVisibility(
                visible = calculatedTotal != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                calculatedTotal?.let { totalVal ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SuccessGreenLight)
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "الإجمالي التلقائي للصنف:",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextDarkPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                text = FormatUtils.formatCurrency(totalVal),
                                style = MaterialTheme.typography.titleMedium,
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Step 4: الملاحظات (Notes / Details)
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    StepNumberBadge(number = "4")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الملاحظات",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextDarkPrimary
                    )
                    Text(
                        text = " (اختياري)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
                OutlinedTextField(
                    value = details,
                    onValueChange = onDetailsChange,
                    placeholder = { Text("أدخل أي ملاحظات إضافية حول الصنف...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    },
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        textDirection = TextDirection.ContentOrRtl,
                        textAlign = TextAlign.Start
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { onSubmit() }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = BorderStroke
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(detailsFocusRequester)
                        .testTag("input_item_details")
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Submit Button
            Button(
                onClick = onSubmit,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryBlue,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("button_add_item")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إضافة الصنف إلى القائمة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun StepNumberBadge(number: String) {
    Box(
        modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(PrimaryBlueLight),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = number,
            color = PrimaryBlue,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 12.sp
        )
    }
}
