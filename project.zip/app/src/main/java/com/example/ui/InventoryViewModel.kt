package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.InventoryDatabase
import com.example.data.model.InventoryItem
import com.example.data.model.InventorySession
import com.example.data.model.InventorySessionSummary
import com.example.data.repository.InventoryRepository
import com.example.util.FormatUtils
import com.example.util.NetworkMonitor
import com.example.util.PdfExporter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import android.net.Uri
import com.example.util.BackupManager
import java.io.File
import java.util.UUID

sealed class UiNotification {
    data class Success(val message: String) : UiNotification()
    data class Error(val message: String) : UiNotification()
    data class Info(val message: String) : UiNotification()
}

enum class FormFieldFocus {
    NAME, QUANTITY, PRICE, DETAILS, NONE
}

class InventoryViewModel(application: Application) : AndroidViewModel(application) {

    private val db = InventoryDatabase.getDatabase(application)
    private val repository = InventoryRepository(db.inventoryDao())
    private val networkMonitor = NetworkMonitor(application)

    // Sessions List
    val sessions: StateFlow<List<InventorySessionSummary>> = repository.allSessionSummaries
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Selected Session State (null = Session List Screen, non-null = Inventory Screen)
    private val _selectedSession = MutableStateFlow<InventorySession?>(null)
    val selectedSession: StateFlow<InventorySession?> = _selectedSession.asStateFlow()

    // Items list for currently selected session (or empty if no session selected)
    @OptIn(ExperimentalCoroutinesApi::class)
    val items: StateFlow<List<InventoryItem>> = _selectedSession.flatMapLatest { session ->
        if (session == null) {
            flowOf(emptyList())
        } else {
            repository.getItemsForSession(session.id)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Search Query State
    var searchQuery = MutableStateFlow("")
        private set

    val filteredItems: StateFlow<List<InventoryItem>> = items.combine(searchQuery) { itemList, query ->
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            itemList
        } else {
            itemList.filter { it.name.contains(trimmed, ignoreCase = true) }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onSearchQueryChange(query: String) {
        searchQuery.value = query
    }

    fun clearSearchQuery() {
        searchQuery.value = ""
    }

    // Add Item Form State
    var nameInput = MutableStateFlow("")
        private set
    var quantityInput = MutableStateFlow("")
        private set
    var priceInput = MutableStateFlow("")
        private set
    var detailsInput = MutableStateFlow("")
        private set

    var nameError = MutableStateFlow<String?>(null)
        private set
    var quantityError = MutableStateFlow<String?>(null)
        private set
    var priceError = MutableStateFlow<String?>(null)
        private set

    private val _focusTarget = MutableStateFlow(FormFieldFocus.NONE)
    val focusTarget: StateFlow<FormFieldFocus> = _focusTarget.asStateFlow()

    // Inline Edit State
    private val _editingItemId = MutableStateFlow<String?>(null)
    val editingItemId: StateFlow<String?> = _editingItemId.asStateFlow()

    var editName = MutableStateFlow("")
    var editQuantity = MutableStateFlow("")
    var editPrice = MutableStateFlow("")
    var editDetails = MutableStateFlow("")
    var editError = MutableStateFlow<String?>(null)

    // Connectivity State
    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _showOnlineRestoredBanner = MutableStateFlow(false)
    val showOnlineRestoredBanner: StateFlow<Boolean> = _showOnlineRestoredBanner.asStateFlow()

    private var onlineBannerJob: Job? = null
    private var hasObservedInitialNetwork = false

    // Notifications
    private val _notifications = MutableSharedFlow<UiNotification>()
    val notifications: SharedFlow<UiNotification> = _notifications.asSharedFlow()

    // PDF Export State
    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _lastExportedFile = MutableStateFlow<File?>(null)
    val lastExportedFile: StateFlow<File?> = _lastExportedFile.asStateFlow()

    // Backup & Restore State
    private val _isBackupOperating = MutableStateFlow(false)
    val isBackupOperating: StateFlow<Boolean> = _isBackupOperating.asStateFlow()

    private val _lastBackupFile = MutableStateFlow<File?>(null)
    val lastBackupFile: StateFlow<File?> = _lastBackupFile.asStateFlow()

    init {
        observeConnectivity()
        viewModelScope.launch {
            repository.checkAndMigrateLegacyItems()
        }
    }

    // Session Management
    fun openSession(session: InventorySession) {
        _selectedSession.value = session
        clearForm()
        clearSearchQuery()
        _editingItemId.value = null
    }

    fun openSessionById(sessionId: String) {
        viewModelScope.launch {
            val session = repository.getSessionById(sessionId)
            if (session != null) {
                openSession(session)
            }
        }
    }

    fun closeSession() {
        _selectedSession.value = null
        clearForm()
        clearSearchQuery()
        _editingItemId.value = null
    }

    fun createSession(name: String, onSessionCreated: ((InventorySession) -> Unit)? = null) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            viewModelScope.launch {
                _notifications.emit(UiNotification.Error("يرجى إدخال اسم الجرد"))
            }
            return
        }

        val newSession = InventorySession(
            id = UUID.randomUUID().toString(),
            name = trimmed,
            createdAt = System.currentTimeMillis()
        )

        viewModelScope.launch {
            repository.addSession(newSession)
            _selectedSession.value = newSession
            clearForm()
            clearSearchQuery()
            _notifications.emit(UiNotification.Success("تم إنشاء جرد جديد: $trimmed"))
            onSessionCreated?.invoke(newSession)
        }
    }

    fun deleteSession(sessionId: String, sessionName: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_selectedSession.value?.id == sessionId) {
                _selectedSession.value = null
            }
            _notifications.emit(UiNotification.Success("تم حذف الجرد \"$sessionName\" بنجاح"))
        }
    }

    private fun observeConnectivity() {
        viewModelScope.launch {
            networkMonitor.isOnline.collect { online ->
                val prev = _isOnline.value
                _isOnline.value = online

                if (!hasObservedInitialNetwork) {
                    hasObservedInitialNetwork = true
                } else if (!prev && online) {
                    // Transitioned from Offline -> Online: show green banner for 3s
                    onlineBannerJob?.cancel()
                    _showOnlineRestoredBanner.value = true
                    onlineBannerJob = viewModelScope.launch {
                        delay(3000)
                        _showOnlineRestoredBanner.value = false
                    }
                }
            }
        }
    }

    // Add Item Form Operations
    fun onNameChange(value: String) {
        nameInput.value = value
        if (nameError.value != null && value.isNotBlank()) {
            nameError.value = null
        }
    }

    fun onQuantityChange(value: String) {
        quantityInput.value = value
        if (quantityError.value != null && value.isNotBlank()) {
            quantityError.value = null
        }
    }

    fun onPriceChange(value: String) {
        priceInput.value = value
        if (priceError.value != null && value.isNotBlank()) {
            priceError.value = null
        }
    }

    fun onDetailsChange(value: String) {
        detailsInput.value = value
    }

    fun clearFocusTarget() {
        _focusTarget.value = FormFieldFocus.NONE
    }

    fun submitAddItem() {
        val name = nameInput.value.trim()
        val qty = quantityInput.value.trim().toDoubleOrNull()
        val price = priceInput.value.trim().toDoubleOrNull()
        val details = detailsInput.value.trim().ifEmpty { null }

        var hasError = false

        if (name.isEmpty()) {
            nameError.value = "اسم الصنف مطلوب"
            _focusTarget.value = FormFieldFocus.NAME
            hasError = true
        } else {
            nameError.value = null
        }

        if (qty == null || qty <= 0.0) {
            quantityError.value = "الكمية يجب أن تكون أكبر من الصفر"
            if (!hasError) {
                _focusTarget.value = FormFieldFocus.QUANTITY
                hasError = true
            }
        } else {
            quantityError.value = null
        }

        if (price == null || price <= 0.0) {
            priceError.value = "السعر يجب أن يكون أكبر من الصفر"
            if (!hasError) {
                _focusTarget.value = FormFieldFocus.PRICE
                hasError = true
            }
        } else {
            priceError.value = null
        }

        if (hasError) return

        val sessionId = _selectedSession.value?.id ?: "legacy_inventory"
        val total = qty!! * price!!

        val newItem = InventoryItem(
            sessionId = sessionId,
            name = name,
            quantity = qty,
            price = price,
            total = total,
            details = details,
            timestamp = System.currentTimeMillis()
        )

        viewModelScope.launch {
            repository.addItem(newItem)
            clearForm()
            _focusTarget.value = FormFieldFocus.NAME
            _notifications.emit(UiNotification.Success("تمت الإضافة: تم حفظ الصنف بنجاح"))
        }
    }

    private fun clearForm() {
        nameInput.value = ""
        quantityInput.value = ""
        priceInput.value = ""
        detailsInput.value = ""
        nameError.value = null
        quantityError.value = null
        priceError.value = null
        _focusTarget.value = FormFieldFocus.NONE
    }

    // Inline Edit Operations
    fun startEditing(item: InventoryItem) {
        _editingItemId.value = item.id
        editName.value = item.name
        editQuantity.value = FormatUtils.formatDecimal(item.quantity)
        editPrice.value = FormatUtils.formatDecimal(item.price)
        editDetails.value = item.details ?: ""
        editError.value = null
    }

    fun cancelEditing() {
        _editingItemId.value = null
        editError.value = null
    }

    fun saveEditing(originalItem: InventoryItem) {
        val name = editName.value.trim()
        val qty = editQuantity.value.trim().toDoubleOrNull()
        val price = editPrice.value.trim().toDoubleOrNull()
        val details = editDetails.value.trim().ifEmpty { null }

        if (name.isEmpty()) {
            editError.value = "اسم الصنف مطلوب"
            return
        }

        if (qty == null || qty <= 0.0) {
            editError.value = "الكمية يجب أن تكون أكبر من الصفر"
            return
        }

        if (price == null || price <= 0.0) {
            editError.value = "السعر يجب أن يكون أكبر من الصفر"
            return
        }

        val updatedItem = originalItem.copy(
            sessionId = originalItem.sessionId,
            name = name,
            quantity = qty,
            price = price,
            total = qty * price,
            details = details
        )

        viewModelScope.launch {
            repository.updateItem(updatedItem)
            _editingItemId.value = null
            editError.value = null
            _notifications.emit(UiNotification.Success("تم التحديث: تم تحديث بيانات الصنف بنجاح"))
        }
    }

    // Delete item
    fun deleteItem(item: InventoryItem) {
        viewModelScope.launch {
            repository.deleteItem(item)
            _notifications.emit(UiNotification.Success("تم الحذف: تم حذف ${item.name} من القائمة"))
        }
    }

    // PDF Export
    fun exportPdf(isDarkMode: Boolean = false) {
        val currentItems = if (searchQuery.value.isNotBlank() && filteredItems.value.isNotEmpty()) {
            filteredItems.value
        } else {
            items.value
        }

        if (currentItems.isEmpty()) {
            viewModelScope.launch {
                _notifications.emit(UiNotification.Error("لا توجد أصناف لتصديرها. أضف أصناف أولاً."))
            }
            return
        }

        val sessionName = _selectedSession.value?.name

        _isExporting.value = true
        viewModelScope.launch {
            val result = PdfExporter.exportToPdf(
                context = getApplication(),
                items = currentItems,
                isDarkMode = isDarkMode,
                sessionName = sessionName
            )
            _isExporting.value = false

            result.fold(
                onSuccess = { file ->
                    _lastExportedFile.value = file
                    _notifications.emit(UiNotification.Success("✓ تم التصدير بنجاح: تم تصدير البيانات إلى ملف PDF بنجاح"))
                },
                onFailure = { error ->
                    _notifications.emit(UiNotification.Error("حدث خطأ أثناء تصدير ملف PDF: ${error.localizedMessage ?: "خطأ غير معروف"}"))
                }
            )
        }
    }

    fun clearLastExportedFile() {
        _lastExportedFile.value = null
    }

    // === BACKUP & RESTORE (JSON) ===
    fun exportBackupJson() {
        if (_isBackupOperating.value) return
        _isBackupOperating.value = true

        viewModelScope.launch {
            try {
                val sessionsList = repository.getAllSessionsList()
                val itemsList = repository.getAllItemsList()

                val result = BackupManager.exportBackupToFile(
                    context = getApplication(),
                    sessions = sessionsList,
                    items = itemsList
                )

                _isBackupOperating.value = false

                result.fold(
                    onSuccess = { file ->
                        _lastBackupFile.value = file
                        _notifications.emit(
                            UiNotification.Success(
                                "✓ تم تصدير النسخة الاحتياطية بنجاح (${sessionsList.size} جرد، ${itemsList.size} صنف)"
                            )
                        )
                    },
                    onFailure = { err ->
                        _notifications.emit(
                            UiNotification.Error("فشل تصدير النسخة الاحتياطية: ${err.localizedMessage ?: "خطأ غير معروف"}")
                        )
                    }
                )
            } catch (e: Exception) {
                _isBackupOperating.value = false
                _notifications.emit(UiNotification.Error("حدث خطأ أثناء التصدير: ${e.localizedMessage ?: "خطأ غير معروف"}"))
            }
        }
    }

    fun exportBackupToUri(uri: Uri) {
        if (_isBackupOperating.value) return
        _isBackupOperating.value = true

        viewModelScope.launch {
            try {
                val sessionsList = repository.getAllSessionsList()
                val itemsList = repository.getAllItemsList()

                val result = BackupManager.exportBackupToUri(
                    context = getApplication(),
                    uri = uri,
                    sessions = sessionsList,
                    items = itemsList
                )

                _isBackupOperating.value = false

                result.fold(
                    onSuccess = {
                        _notifications.emit(
                            UiNotification.Success(
                                "✓ تم حفظ النسخة الاحتياطية (JSON) بنجاح على الهاتف (${sessionsList.size} جرد، ${itemsList.size} صنف)"
                            )
                        )
                    },
                    onFailure = { err ->
                        _notifications.emit(
                            UiNotification.Error("تعذر حفظ النسخة الاحتياطية: ${err.localizedMessage ?: "خطأ غير معروف"}")
                        )
                    }
                )
            } catch (e: Exception) {
                _isBackupOperating.value = false
                _notifications.emit(UiNotification.Error("خطأ في حفظ الملف: ${e.localizedMessage ?: "خطأ غير معروف"}"))
            }
        }
    }

    fun importBackupFromUri(uri: Uri, clearExisting: Boolean = false) {
        if (_isBackupOperating.value) return
        _isBackupOperating.value = true

        viewModelScope.launch {
            try {
                val result = BackupManager.importBackupFromUri(
                    context = getApplication(),
                    uri = uri
                )

                if (result.isFailure) {
                    _isBackupOperating.value = false
                    val err = result.exceptionOrNull()
                    _notifications.emit(
                        UiNotification.Error("فشل قراءة ملف النسخة الاحتياطية: ${err?.localizedMessage ?: "تنسيق غير صالح"}")
                    )
                    return@launch
                }

                val (backupSessions, backupItems) = result.getOrThrow()

                repository.restoreDatabase(
                    sessions = backupSessions,
                    items = backupItems,
                    clearExisting = clearExisting
                )

                _isBackupOperating.value = false

                // Refresh current session state if needed
                val current = _selectedSession.value
                if (current != null) {
                    val refreshed = repository.getSessionById(current.id)
                    _selectedSession.value = refreshed
                }

                _notifications.emit(
                    UiNotification.Success(
                        "✓ تم استعادة البيانات بنجاح: تم استرجاع ${backupSessions.size} جرد و ${backupItems.size} صنف"
                    )
                )
            } catch (e: Exception) {
                _isBackupOperating.value = false
                _notifications.emit(
                    UiNotification.Error("حدث خطأ أثناء استعادة البيانات: ${e.localizedMessage ?: "خطأ غير معروف"}")
                )
            }
        }
    }

    fun clearLastBackupFile() {
        _lastBackupFile.value = null
    }
}
