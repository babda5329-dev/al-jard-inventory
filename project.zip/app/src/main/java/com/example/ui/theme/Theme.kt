package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = PrimaryBlueLight,
    onPrimaryContainer = PrimaryBlueDark,
    secondary = AccentTeal,
    onSecondary = Color.White,
    secondaryContainer = AccentTealLight,
    onSecondaryContainer = AccentTeal,
    background = BackgroundGray,
    onBackground = TextDarkPrimary,
    surface = SurfaceWhite,
    onSurface = TextDarkPrimary,
    surfaceVariant = SurfaceVariantSlate,
    onSurfaceVariant = TextDarkSecondary,
    outline = BorderStroke,
    error = ErrorRed,
    onError = Color.White,
    errorContainer = ErrorRedLight,
    onErrorContainer = ErrorRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = Typography,
        content = content
    )
}
