package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.InventorySession
import com.example.ui.components.AddItemCard
import com.example.ui.components.ExportPdfDialog
import com.example.ui.components.FooterSection
import com.example.ui.components.HeaderSection
import com.example.ui.components.InventoryTableCard
import com.example.ui.components.PdfExportSuccessDialog
import com.example.ui.theme.BackgroundGray

@Composable
fun InventoryScreen(
    viewModel: InventoryViewModel,
    modifier: Modifier = Modifier
) {
    val selectedSession by viewModel.selectedSession.collectAsStateWithLifecycle()

    if (selectedSession == null) {
        SessionsListScreen(
            viewModel = viewModel,
            modifier = modifier
        )
    } else {
        InventorySessionContent(
            session = selectedSession!!,
            viewModel = viewModel,
            modifier = modifier
        )
    }
}

@Composable
private fun InventorySessionContent(
    session: InventorySession,
    viewModel: InventoryViewModel,
    modifier: Modifier = Modifier
) {
    // Intercept back button to return smoothly to sessions list
    BackHandler {
        viewModel.closeSession()
    }

    val items by viewModel.items.collectAsStateWithLifecycle()
    val filteredItems by viewModel.filteredItems.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val showOnlineRestoredBanner by viewModel.showOnlineRestoredBanner.collectAsStateWithLifecycle()

    val nameInput by viewModel.nameInput.collectAsStateWithLifecycle()
    val quantityInput by viewModel.quantityInput.collectAsStateWithLifecycle()
    val priceInput by viewModel.priceInput.collectAsStateWithLifecycle()
    val detailsInput by viewModel.detailsInput.collectAsStateWithLifecycle()

    val nameError by viewModel.nameError.collectAsStateWithLifecycle()
    val quantityError by viewModel.quantityError.collectAsStateWithLifecycle()
    val priceError by viewModel.priceError.collectAsStateWithLifecycle()
    val focusTarget by viewModel.focusTarget.collectAsStateWithLifecycle()

    val editingItemId by viewModel.editingItemId.collectAsStateWithLifecycle()
    val editName by viewModel.editName.collectAsStateWithLifecycle()
    val editQuantity by viewModel.editQuantity.collectAsStateWithLifecycle()
    val editPrice by viewModel.editPrice.collectAsStateWithLifecycle()
    val editDetails by viewModel.editDetails.collectAsStateWithLifecycle()
    val editError by viewModel.editError.collectAsStateWithLifecycle()

    val isExporting by viewModel.isExporting.collectAsStateWithLifecycle()
    val lastExportedFile by viewModel.lastExportedFile.collectAsStateWithLifecycle()

    var showExportPdfDialog by remember { mutableStateOf(false) }
    var showCreateNewSessionDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.notifications.collect { notification ->
            when (notification) {
                is UiNotification.Success -> {
                    snackbarHostState.showSnackbar(message = notification.message)
                }
                is UiNotification.Error -> {
                    snackbarHostState.showSnackbar(message = notification.message)
                }
                is UiNotification.Info -> {
                    snackbarHostState.showSnackbar(message = notification.message)
                }
            }
        }
    }

    // Force Arabic RTL layout direction for authentic Arabic interface
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = modifier
                .fillMaxSize()
                .testTag("inventory_screen"),
            containerColor = BackgroundGray,
            snackbarHost = {
                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier.testTag("inventory_snackbar_host")
                ) { snackbarData ->
                    Snackbar(
                        snackbarData = snackbarData,
                        shape = RoundedCornerShape(10.dp),
                        containerColor = Color(0xFF1E293B),
                        contentColor = Color.White
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 1100.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // 1. Header with Session Navigation and Offline Status
                    HeaderSection(
                        isOnline = isOnline,
                        showOnlineRestoredBanner = showOnlineRestoredBanner,
                        sessionName = session.name,
                        onBackToSessions = viewModel::closeSession,
                        onCreateNewSession = { showCreateNewSessionDialog = true }
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        // 2. Add Inventory Items Card
                        AddItemCard(
                            name = nameInput,
                            onNameChange = viewModel::onNameChange,
                            nameError = nameError,
                            quantity = quantityInput,
                            onQuantityChange = viewModel::onQuantityChange,
                            quantityError = quantityError,
                            price = priceInput,
                            onPriceChange = viewModel::onPriceChange,
                            priceError = priceError,
                            details = detailsInput,
                            onDetailsChange = viewModel::onDetailsChange,
                            focusTarget = focusTarget,
                            onFocusHandled = viewModel::clearFocusTarget,
                            onSubmit = viewModel::submitAddItem
                        )

                        // 3. Inventory Table Card
                        InventoryTableCard(
                            items = filteredItems,
                            editingItemId = editingItemId,
                            editName = editName,
                            onEditNameChange = { viewModel.editName.value = it },
                            editQuantity = editQuantity,
                            onEditQuantityChange = { viewModel.editQuantity.value = it },
                            editPrice = editPrice,
                            onEditPriceChange = { viewModel.editPrice.value = it },
                            editDetails = editDetails,
                            onEditDetailsChange = { viewModel.editDetails.value = it },
                            editError = editError,
                            onStartEdit = viewModel::startEditing,
                            onSaveEdit = viewModel::saveEditing,
                            onCancelEdit = viewModel::cancelEditing,
                            onDeleteItem = viewModel::deleteItem,
                            onExportPdf = { showExportPdfDialog = true },
                            isExporting = isExporting,
                            searchQuery = searchQuery,
                            onSearchQueryChange = viewModel::onSearchQueryChange,
                            onClearSearchQuery = viewModel::clearSearchQuery,
                            totalItemsCount = items.size
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // 4. Footer Section
                    FooterSection()
                }

                // PDF Export Theme Selection Dialog
                if (showExportPdfDialog) {
                    ExportPdfDialog(
                        onDismiss = { showExportPdfDialog = false },
                        onConfirmExport = { isDarkMode ->
                            viewModel.exportPdf(isDarkMode)
                        }
                    )
                }

                // Create New Session Dialog (allows starting a separate inventory at any time)
                if (showCreateNewSessionDialog) {
                    CreateSessionDialog(
                        onDismiss = { showCreateNewSessionDialog = false },
                        onConfirm = { newName ->
                            viewModel.createSession(newName)
                            showCreateNewSessionDialog = false
                        }
                    )
                }

                // PDF Export Success Dialog
                lastExportedFile?.let { file ->
                    PdfExportSuccessDialog(
                        file = file,
                        onDismiss = viewModel::clearLastExportedFile
                    )
                }
            }
        }
    }
}
