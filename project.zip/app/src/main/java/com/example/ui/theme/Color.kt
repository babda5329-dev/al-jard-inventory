package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF2196F3)
val PrimaryBlueDark = Color(0xFF1976D2)
val PrimaryBlueLight = Color(0xFFE3F2FD)

val AccentTeal = Color(0xFF009688)
val AccentTealLight = Color(0xFFE0F2F1)

val BackgroundGray = Color(0xFFF1F5F9)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceVariantSlate = Color(0xFFF8FAFC)

val TextDarkPrimary = Color(0xFF0F172A)
val TextDarkSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF64748B)

val BorderStroke = Color(0xFFE2E8F0)
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenLight = Color(0xFFDCFCE7)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedLight = Color(0xFFFEE2E2)
