package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.InventoryItem
import com.example.util.FormatUtils
import com.example.util.PdfExporter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches arabic app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("الجرد المخزني", appName)
    }

    @Test
    fun `inventory item total calculation is correct`() {
        val quantity = 12.50
        val price = 2500.00
        val total = quantity * price

        val item = InventoryItem(
            name = "أرز بسمتي",
            quantity = quantity,
            price = price,
            total = total
        )

        assertEquals(31250.00, item.total, 0.001)
        assertEquals("12.50", FormatUtils.formatDecimal(item.quantity))
        assertEquals("2500.00", FormatUtils.formatDecimal(item.price))
        assertEquals("31250.00", FormatUtils.formatDecimal(item.total))
        assertEquals("31250.00 ريال يمني", FormatUtils.formatCurrency(item.total))
    }

    @Test
    fun `inventory viewModel initializes cleanly without crash`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.ui.InventoryViewModel(app)
        assertNotNull(viewModel)
        assertNotNull(viewModel.items.value)
        assertNotNull(viewModel.isOnline.value)
    }

    @Test
    fun `search query filtering works as expected`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.ui.InventoryViewModel(app)
        viewModel.onSearchQueryChange("سكر")
        assertEquals("سكر", viewModel.searchQuery.value)
        viewModel.clearSearchQuery()
        assertEquals("", viewModel.searchQuery.value)
    }

    @Test
    fun `format utils handles various prices and decimals correctly`() {
        assertEquals("0.00", FormatUtils.formatDecimal(0.0))
        assertEquals("100.50", FormatUtils.formatDecimal(100.5))
        assertEquals("1234.56", FormatUtils.formatDecimal(1234.56))
        assertEquals("1234.56 ريال يمني", FormatUtils.formatCurrency(1234.56))

        // Check formatYear
        val testCal = java.util.Calendar.getInstance().apply {
            set(2026, java.util.Calendar.OCTOBER, 10)
        }
        assertEquals("2026", FormatUtils.formatYear(testCal.timeInMillis))
    }

    @Test
    fun `sequential form input validation targets correct field on error`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.ui.InventoryViewModel(app)

        // Empty form submit targets NAME
        viewModel.submitAddItem()
        assertEquals(com.example.ui.FormFieldFocus.NAME, viewModel.focusTarget.value)

        // Filling NAME and submitting with empty quantity targets QUANTITY
        viewModel.onNameChange("أرز بسمتي")
        viewModel.submitAddItem()
        assertEquals(com.example.ui.FormFieldFocus.QUANTITY, viewModel.focusTarget.value)

        // Filling QUANTITY and submitting with empty price targets PRICE
        viewModel.onQuantityChange("5.0")
        viewModel.submitAddItem()
        assertEquals(com.example.ui.FormFieldFocus.PRICE, viewModel.focusTarget.value)

        // Resetting focus
        viewModel.clearFocusTarget()
        assertEquals(com.example.ui.FormFieldFocus.NONE, viewModel.focusTarget.value)
    }

    @Test
    fun `multiple independent inventory sessions have separate items and grand totals`() {
        val session1 = com.example.data.model.InventorySession(
            name = "جرد شهر أكتوبر"
        )
        val session2 = com.example.data.model.InventorySession(
            name = "جرد المخزن الفرعي"
        )

        // Verify unique IDs and creation dates
        assertTrue(session1.id.isNotBlank())
        assertTrue(session2.id.isNotBlank())
        org.junit.Assert.assertNotEquals(session1.id, session2.id)
        assertTrue(session1.createdAt > 0L)
        assertTrue(session2.createdAt > 0L)

        // Session 1 items
        val item1 = InventoryItem(
            sessionId = session1.id,
            name = "سكر أبيض",
            quantity = 10.0,
            price = 500.0,
            total = 5000.0
        )
        val item2 = InventoryItem(
            sessionId = session1.id,
            name = "شاي أسود",
            quantity = 2.0,
            price = 1000.0,
            total = 2000.0
        )
        val session1Items = listOf(item1, item2)
        val session1Total = session1Items.sumOf { it.total }
        assertEquals(7000.0, session1Total, 0.001)

        // Session 2 items
        val item3 = InventoryItem(
            sessionId = session2.id,
            name = "زيت نباتي",
            quantity = 5.0,
            price = 3000.0,
            total = 15000.0
        )
        val session2Items = listOf(item3)
        val session2Total = session2Items.sumOf { it.total }
        assertEquals(15000.0, session2Total, 0.001)

        // Confirm total separation
        assertEquals(2, session1Items.size)
        assertEquals(1, session2Items.size)
        org.junit.Assert.assertNotEquals(session1Total, session2Total)
    }

    @Test
    fun `export and import database json backup maintains sessions and items integrity`() {
        val session1 = com.example.data.model.InventorySession(
            name = "جرد تجريبي 1"
        )
        val item1 = InventoryItem(
            sessionId = session1.id,
            name = "تمر فاخر",
            quantity = 20.0,
            price = 1500.0,
            total = 30000.0,
            details = "كرتون ممتاز"
        )

        val json = com.example.util.BackupManager.createBackupJson(
            sessions = listOf(session1),
            items = listOf(item1)
        )

        assertTrue(json.contains("تمر فاخر"))
        assertTrue(json.contains("جرد تجريبي 1"))
        assertTrue(json.contains("30000.0"))

        val parseResult = com.example.util.BackupManager.parseBackupJson(json)
        assertTrue(parseResult.isSuccess)

        val (parsedSessions, parsedItems) = parseResult.getOrThrow()
        assertEquals(1, parsedSessions.size)
        assertEquals(session1.id, parsedSessions[0].id)
        assertEquals(session1.name, parsedSessions[0].name)

        assertEquals(1, parsedItems.size)
        assertEquals(item1.id, parsedItems[0].id)
        assertEquals(item1.name, parsedItems[0].name)
        assertEquals(item1.quantity, parsedItems[0].quantity, 0.001)
        assertEquals(item1.price, parsedItems[0].price, 0.001)
        assertEquals(item1.total, parsedItems[0].total, 0.001)
        assertEquals(item1.details, parsedItems[0].details)
    }
}
